//
//  NotificationVc.h
//  
//
//  Created by katoch on 25/12/17.
//

#import <UIKit/UIKit.h>

@interface NotificationVc : UIViewController

- (IBAction)backClicked:(id)sender;
@end
