//
//  NotificationVc.m
//  
//
//  Created by katoch on 25/12/17.
//

#import "NotificationVc.h"

@interface NotificationVc ()

@end

@implementation NotificationVc

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)backClicked:(id)sender {
     [self.navigationController popViewControllerAnimated:YES];
}
@end
